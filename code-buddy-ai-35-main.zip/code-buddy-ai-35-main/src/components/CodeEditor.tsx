import Editor from "@monaco-editor/react";
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Play, Copy, Download, RotateCcw } from "lucide-react";
import { toast } from "@/hooks/use-toast";

const LANGUAGES = [
  { id: "javascript", name: "JavaScript", icon: "JS" },
  { id: "typescript", name: "TypeScript", icon: "TS" },
  { id: "python", name: "Python", icon: "PY" },
  { id: "java", name: "Java", icon: "JV" },
  { id: "cpp", name: "C++", icon: "C+" },
  { id: "csharp", name: "C#", icon: "C#" },
  { id: "go", name: "Go", icon: "GO" },
  { id: "rust", name: "Rust", icon: "RS" },
  { id: "ruby", name: "Ruby", icon: "RB" },
  { id: "php", name: "PHP", icon: "PH" },
  { id: "swift", name: "Swift", icon: "SW" },
  { id: "kotlin", name: "Kotlin", icon: "KT" },
  { id: "html", name: "HTML", icon: "HT" },
  { id: "css", name: "CSS", icon: "CS" },
  { id: "sql", name: "SQL", icon: "SQ" },
];

const DEFAULT_CODE: Record<string, string> = {
  javascript: `// Welcome to CodeCraft AI!
// Start coding in JavaScript

function greet(name) {
  return \`Hello, \${name}! Welcome to CodeCraft.\`;
}

console.log(greet("Developer"));
`,
  typescript: `// Welcome to CodeCraft AI!
// Start coding in TypeScript

interface User {
  name: string;
  role: string;
}

function greet(user: User): string {
  return \`Hello, \${user.name}! You are a \${user.role}.\`;
}

console.log(greet({ name: "Developer", role: "Engineer" }));
`,
  python: `# Welcome to CodeCraft AI!
# Start coding in Python

def greet(name: str) -> str:
    return f"Hello, {name}! Welcome to CodeCraft."

if __name__ == "__main__":
    print(greet("Developer"))
`,
  java: `// Welcome to CodeCraft AI!
// Start coding in Java

public class Main {
    public static void main(String[] args) {
        System.out.println(greet("Developer"));
    }
    
    public static String greet(String name) {
        return "Hello, " + name + "! Welcome to CodeCraft.";
    }
}
`,
  cpp: `// Welcome to CodeCraft AI!
// Start coding in C++

#include <iostream>
#include <string>

std::string greet(const std::string& name) {
    return "Hello, " + name + "! Welcome to CodeCraft.";
}

int main() {
    std::cout << greet("Developer") << std::endl;
    return 0;
}
`,
  csharp: `// Welcome to CodeCraft AI!
// Start coding in C#

using System;

class Program {
    static void Main() {
        Console.WriteLine(Greet("Developer"));
    }
    
    static string Greet(string name) {
        return $"Hello, {name}! Welcome to CodeCraft.";
    }
}
`,
  go: `// Welcome to CodeCraft AI!
// Start coding in Go

package main

import "fmt"

func greet(name string) string {
    return fmt.Sprintf("Hello, %s! Welcome to CodeCraft.", name)
}

func main() {
    fmt.Println(greet("Developer"))
}
`,
  rust: `// Welcome to CodeCraft AI!
// Start coding in Rust

fn greet(name: &str) -> String {
    format!("Hello, {}! Welcome to CodeCraft.", name)
}

fn main() {
    println!("{}", greet("Developer"));
}
`,
  ruby: `# Welcome to CodeCraft AI!
# Start coding in Ruby

def greet(name)
  "Hello, #{name}! Welcome to CodeCraft."
end

puts greet("Developer")
`,
  php: `<?php
// Welcome to CodeCraft AI!
// Start coding in PHP

function greet($name) {
    return "Hello, {$name}! Welcome to CodeCraft.";
}

echo greet("Developer");
`,
  swift: `// Welcome to CodeCraft AI!
// Start coding in Swift

func greet(_ name: String) -> String {
    return "Hello, \\(name)! Welcome to CodeCraft."
}

print(greet("Developer"))
`,
  kotlin: `// Welcome to CodeCraft AI!
// Start coding in Kotlin

fun greet(name: String): String {
    return "Hello, $name! Welcome to CodeCraft."
}

fun main() {
    println(greet("Developer"))
}
`,
  html: `<!-- Welcome to CodeCraft AI! -->
<!-- Start coding in HTML -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CodeCraft AI</title>
</head>
<body>
    <h1>Hello, Developer!</h1>
    <p>Welcome to CodeCraft.</p>
</body>
</html>
`,
  css: `/* Welcome to CodeCraft AI! */
/* Start coding in CSS */

:root {
    --primary: #00d4ff;
    --background: #0a0f1a;
}

body {
    font-family: 'Inter', sans-serif;
    background: var(--background);
    color: white;
}

h1 {
    color: var(--primary);
}
`,
  sql: `-- Welcome to CodeCraft AI!
-- Start coding in SQL

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

SELECT * FROM users WHERE name LIKE '%Developer%';
`,
};

interface CodeEditorProps {
  onCodeChange?: (code: string, language: string) => void;
}

export function CodeEditor({ onCodeChange }: CodeEditorProps) {
  const [language, setLanguage] = useState("javascript");
  const [code, setCode] = useState(DEFAULT_CODE.javascript);

  const handleLanguageChange = (newLang: string) => {
    setLanguage(newLang);
    const newCode = DEFAULT_CODE[newLang] || `// Start coding in ${newLang}`;
    setCode(newCode);
    onCodeChange?.(newCode, newLang);
  };

  const handleCodeChange = (value: string | undefined) => {
    const newCode = value || "";
    setCode(newCode);
    onCodeChange?.(newCode, language);
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    toast({ title: "Copied!", description: "Code copied to clipboard" });
  };

  const handleDownload = () => {
    const extensions: Record<string, string> = {
      javascript: "js",
      typescript: "ts",
      python: "py",
      java: "java",
      cpp: "cpp",
      csharp: "cs",
      go: "go",
      rust: "rs",
      ruby: "rb",
      php: "php",
      swift: "swift",
      kotlin: "kt",
      html: "html",
      css: "css",
      sql: "sql",
    };
    const ext = extensions[language] || "txt";
    const blob = new Blob([code], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `code.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Downloaded!", description: `File saved as code.${ext}` });
  };

  const handleReset = () => {
    const defaultCode = DEFAULT_CODE[language] || `// Start coding in ${language}`;
    setCode(defaultCode);
    onCodeChange?.(defaultCode, language);
    toast({ title: "Reset!", description: "Code reset to default" });
  };

  return (
    <div className="flex flex-col h-full code-editor-bg rounded-lg overflow-hidden border border-border/50">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-card/50">
        <div className="flex items-center gap-3">
          <Select value={language} onValueChange={handleLanguageChange}>
            <SelectTrigger className="w-40 bg-secondary border-border/50 focus:ring-primary/50">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-card border-border/50">
              {LANGUAGES.map((lang) => (
                <SelectItem key={lang.id} value={lang.id}>
                  <span className="flex items-center gap-2">
                    <span className="text-xs font-mono text-primary">{lang.icon}</span>
                    {lang.name}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleReset}
            className="text-muted-foreground hover:text-foreground"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleCopy}
            className="text-muted-foreground hover:text-foreground"
          >
            <Copy className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleDownload}
            className="text-muted-foreground hover:text-foreground"
          >
            <Download className="h-4 w-4" />
          </Button>
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2">
            <Play className="h-4 w-4" />
            Run
          </Button>
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 min-h-0">
        <Editor
          height="100%"
          language={language}
          value={code}
          onChange={handleCodeChange}
          theme="vs-dark"
          options={{
            fontSize: 14,
            fontFamily: "'JetBrains Mono', monospace",
            minimap: { enabled: false },
            scrollBeyondLastLine: false,
            lineNumbers: "on",
            renderLineHighlight: "all",
            cursorBlinking: "smooth",
            smoothScrolling: true,
            padding: { top: 16 },
            bracketPairColorization: { enabled: true },
            automaticLayout: true,
          }}
        />
      </div>
    </div>
  );
}
