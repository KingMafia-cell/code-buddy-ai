import { Code, Play, MessageSquare } from "lucide-react";
import { cn } from "@/lib/utils";

export type TabType = "code" | "output" | "chat";

interface BottomNavProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const tabs = [
    { id: "code" as TabType, label: "Code", icon: Code },
    { id: "output" as TabType, label: "Live", icon: Play },
    { id: "chat" as TabType, label: "AI Chat", icon: MessageSquare },
  ];

  return (
    <nav className="flex items-center justify-around px-4 py-2 border-t border-border/50 bg-card/80 backdrop-blur-xl">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              "flex flex-col items-center gap-1 px-6 py-2 rounded-xl transition-all duration-200",
              isActive 
                ? "text-primary bg-primary/10" 
                : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
            )}
          >
            <Icon className={cn("h-6 w-6", isActive && "animate-pulse")} />
            <span className={cn(
              "text-xs font-medium",
              isActive && "text-primary"
            )}>
              {tab.label}
            </span>
            {isActive && (
              <div className="absolute bottom-0 w-12 h-0.5 bg-primary rounded-full" />
            )}
          </button>
        );
      })}
    </nav>
  );
}
