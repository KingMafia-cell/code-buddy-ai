import { Sparkles } from "lucide-react";

export function Header() {
  return (
    <header className="flex items-center justify-center px-6 py-3 border-b border-border/50 bg-card/50 backdrop-blur-xl">
      <div className="flex items-center gap-3">
        <div className="relative">
          <div className="p-2 rounded-xl bg-gradient-to-br from-primary/20 to-purple-500/20 glow-border">
            <Sparkles className="h-6 w-6 text-primary" />
          </div>
        </div>
        <div>
          <h1 className="font-bold text-xl text-foreground tracking-tight">
            GenZ<span className="text-primary">Coder</span>
          </h1>
          <p className="text-xs text-muted-foreground">Code like a pro ✨</p>
        </div>
      </div>
    </header>
  );
}
