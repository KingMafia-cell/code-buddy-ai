import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { RefreshCw, Maximize2, Minimize2, ExternalLink } from "lucide-react";

interface OutputPanelProps {
  code: string;
  language: string;
}

export function OutputPanel({ code, language }: OutputPanelProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [refreshKey, setRefreshKey] = useState(0);

  const htmlContent = useMemo(() => {
    if (language === "html") {
      return code;
    } else if (language === "css") {
      return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>${code}</style>
</head>
<body>
  <h1>CSS Preview</h1>
  <p>This is a paragraph to demonstrate your CSS styles.</p>
  <button>Sample Button</button>
  <div class="container">
    <div class="box">Box 1</div>
    <div class="box">Box 2</div>
    <div class="box">Box 3</div>
  </div>
</body>
</html>`;
    } else if (language === "javascript" || language === "typescript") {
      return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: 'JetBrains Mono', monospace; 
      background: #ffffff; 
      color: #1a1a2e; 
      padding: 16px;
      min-height: 100vh;
    }
    .console-line { 
      padding: 6px 10px; 
      border-left: 3px solid #00b4d8; 
      margin: 6px 0;
      background: #f0f9ff;
      border-radius: 0 6px 6px 0;
    }
    .console-error { 
      border-left-color: #dc2626; 
      background: #fef2f2;
      color: #991b1b;
    }
    .console-warn { 
      border-left-color: #f59e0b; 
      background: #fffbeb;
      color: #92400e;
    }
    .output-title {
      color: #0891b2;
      margin-bottom: 16px;
      font-size: 13px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
  </style>
</head>
<body>
  <div class="output-title">Console Output</div>
  <div id="output"></div>
  <script>
    const output = document.getElementById('output');
    
    function appendOutput(text, type = 'log') {
      const line = document.createElement('div');
      line.className = 'console-line' + (type === 'error' ? ' console-error' : type === 'warn' ? ' console-warn' : '');
      line.textContent = typeof text === 'object' ? JSON.stringify(text, null, 2) : String(text);
      output.appendChild(line);
    }
    
    console.log = (...args) => { args.forEach(arg => appendOutput(arg, 'log')); };
    console.error = (...args) => { args.forEach(arg => appendOutput(arg, 'error')); };
    console.warn = (...args) => { args.forEach(arg => appendOutput(arg, 'warn')); };
    
    try {
      ${code}
    } catch (error) {
      console.error('Error: ' + error.message);
    }
  </script>
</body>
</html>`;
    } else {
      return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: 'Inter', sans-serif; 
      background: #ffffff; 
      color: #64748b; 
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      text-align: center;
      padding: 20px;
    }
    .container { max-width: 400px; }
    h2 { color: #0891b2; margin-bottom: 12px; }
    p { line-height: 1.6; }
    code { 
      background: #f0f9ff; 
      padding: 2px 8px; 
      border-radius: 4px;
      color: #0891b2;
      font-weight: 500;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Preview Not Available</h2>
    <p>Live preview is available for <code>HTML</code>, <code>CSS</code>, and <code>JavaScript</code>.</p>
    <p style="margin-top: 12px;">For <code>${language}</code>, use the AI assistant to help run and debug your code!</p>
  </div>
</body>
</html>`;
    }
  }, [code, language, refreshKey]);

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
    setLastUpdate(new Date());
  };

  const handleOpenInNewTab = () => {
    const blob = new Blob([htmlContent], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
  };

  return (
    <div className={`flex flex-col h-full code-editor-bg rounded-lg overflow-hidden border border-border/50 ${isFullscreen ? 'fixed inset-4 z-50' : ''}`}>
      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-card/50">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
          <span className="text-sm font-medium text-foreground">Live Output</span>
          <span className="text-xs text-muted-foreground">
            Updated {lastUpdate.toLocaleTimeString()}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            className="text-muted-foreground hover:text-foreground"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
          {(language === "html" || language === "css" || language === "javascript") && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleOpenInNewTab}
              className="text-muted-foreground hover:text-foreground"
            >
              <ExternalLink className="h-4 w-4" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="text-muted-foreground hover:text-foreground"
          >
            {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* Preview Frame */}
      <div className="flex-1 min-h-0 bg-white">
        <iframe
          key={refreshKey}
          title="Code Output"
          className="w-full h-full border-0 bg-white"
          srcDoc={htmlContent}
          sandbox="allow-scripts"
          loading="lazy"
        />
      </div>
    </div>
  );
}
