import { useState } from "react";
import { Header } from "@/components/Header";
import { CodeEditor } from "@/components/CodeEditor";
import { ChatPanel } from "@/components/ChatPanel";
import { OutputPanel } from "@/components/OutputPanel";
import { BottomNav, TabType } from "@/components/BottomNav";

const Index = () => {
  const [code, setCode] = useState("");
  const [language, setLanguage] = useState("javascript");
  const [activeTab, setActiveTab] = useState<TabType>("code");

  const handleCodeChange = (newCode: string, newLanguage: string) => {
    setCode(newCode);
    setLanguage(newLanguage);
  };

  return (
    <div className="flex flex-col h-screen bg-background">
      <Header />
      
      {/* Main Content Area */}
      <div className="flex-1 min-h-0 overflow-hidden">
        {activeTab === "code" && (
          <div className="h-full p-4">
            <CodeEditor onCodeChange={handleCodeChange} />
          </div>
        )}
        
        {activeTab === "output" && (
          <div className="h-full p-4">
            <OutputPanel code={code} language={language} />
          </div>
        )}
        
        {activeTab === "chat" && (
          <div className="h-full">
            <ChatPanel />
          </div>
        )}
      </div>
      
      {/* Bottom Navigation */}
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
};

export default Index;
